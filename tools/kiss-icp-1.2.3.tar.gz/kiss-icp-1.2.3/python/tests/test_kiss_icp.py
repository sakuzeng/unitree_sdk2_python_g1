def test_import():
    from kiss_icp.kiss_icp import KissICP

    assert KissICP is not None
